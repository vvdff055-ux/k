# Auto Totem (Fabric 1.21 – 1.21.11)

Automatically puts a Totem of Undying in your offhand when one is in your inventory.

## Build (GitHub Actions)

1. Create a **new empty** GitHub repository
2. Upload **all files from this folder** (including `.github` folder)
3. Go to **Actions** tab → select **Build mod** → **Run workflow**
4. When green check appears → open the run → **Artifacts** → download `AutoTotem-1.21-1.21.11`
5. Inside you get the playable `.jar` — put it in your `mods` folder with Fabric API

## Requirements in-game
- Minecraft 1.21 – 1.21.11
- Fabric Loader
- Fabric API

## License
MIT
