package com.kodari.autototem;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

public final class AutoTotemClient implements ClientModInitializer {
    // Literal values (instead of PlayerInventory constants) so one jar keeps working across many versions.
    private static final int OFFHAND_SLOT = 40;        // inventory index AND swap "button" for the offhand
    private static final int MAIN_SIZE = 36;           // hotbar (0-8) + main inventory (9-35)
    private static final int HOTBAR_SIZE = 9;
    private static final int HOTBAR_HANDLER_START = 36; // hotbar slot 0 is handler slot 36 in the player screen handler

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(AutoTotemClient::refillOffhand);
    }

    private static void refillOffhand(MinecraftClient client) {
        ClientPlayerEntity player = client.player;
        if (player == null || client.interactionManager == null || client.currentScreen != null) {
            return;
        }

        if (player.currentScreenHandler != player.playerScreenHandler) {
            return;
        }

        PlayerInventory inventory = player.getInventory();
        if (inventory.getStack(OFFHAND_SLOT).isOf(Items.TOTEM_OF_UNDYING)) {
            return;
        }

        for (int inventorySlot = 0; inventorySlot < MAIN_SIZE; inventorySlot++) {
            if (!inventory.getStack(inventorySlot).isOf(Items.TOTEM_OF_UNDYING)) {
                continue;
            }

            int handlerSlot = inventorySlot < HOTBAR_SIZE
                    ? HOTBAR_HANDLER_START + inventorySlot
                    : inventorySlot;
            client.interactionManager.clickSlot(
                    player.currentScreenHandler.syncId,
                    handlerSlot,
                    OFFHAND_SLOT,
                    SlotActionType.SWAP,
                    player
            );
            return;
        }
    }
}
